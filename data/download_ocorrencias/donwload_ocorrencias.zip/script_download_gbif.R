library(dismo)
library(dplyr)
library(tidyr)

gbif_data <- dismo::gbif(
  genus = "Amazona",
  species = "vinacea",
  geo = TRUE,
  removeZeros = TRUE,
  download = TRUE
)

gbif_data <- as.data.frame(gbif_data)

# filtragem dos dados de ocorrência
gbif_data <- gbif_data %>%
  filter(country == "Brazil") %>%  # filtra para o Brasil
  select(species, lon, lat)        # seleciona apenas essas 3 colunas

gbif_data <- gbif_data[, c("species", "lon", "lat")]

# Filter out rows with NA in the longitude or latitude columns
gbif_data <- gbif_data %>%
  filter(!is.na(lon) & !is.na(lat))

# Optionally, remove rows with missing species names if needed
gbif_data <- gbif_data %>%
  filter(!is.na(species))

# remove ocorrências duplicadas e NA
gbif_data <- gbif_data %>%
  distinct()

gbif_data$database <- "gbif"

# Print the geolocation data
print(gbif_data)

write.csv(gbif_data, "variaveis/ocorrencias/gbif_filtrado.csv", row.names = FALSE)
