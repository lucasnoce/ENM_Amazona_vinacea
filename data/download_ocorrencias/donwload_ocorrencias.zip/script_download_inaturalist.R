# Load the package
library(rinat)
library(tidyr)

# Download occurrence data for Amazona vinacea from iNaturalist
species_data <- get_inat_obs(query = "Amazona vinacea")

# View the first few records
head(species_data)

# Filter to retain only geolocation and other key columns
inat_data <- species_data %>%
  dplyr::select(scientific_name, latitude, longitude)

inat_data <- inat_data %>%
  rename(lon = longitude)
inat_data <- inat_data %>%
  rename(lat = latitude)
inat_data <- inat_data %>%
  rename(species = scientific_name)

inat_data <- inat_data[, c("species", "lon", "lat")]

# remove ocorrências duplicadas e NA
inat_data <- inat_data %>%
  distinct() %>%
  drop_na()

inat_data$database <- "iNaturalist"

# Print the geolocation data
print(inat_data)

write.csv(inat_data, "variaveis/ocorrencias/inaturalist_filtrado.csv", row.names = FALSE)
