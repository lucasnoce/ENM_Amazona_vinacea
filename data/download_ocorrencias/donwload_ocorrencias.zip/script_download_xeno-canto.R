library(httr)
library(jsonlite)
library(dplyr)
library(tidyr)

# Define the species name and make the API request
species <- "Amazona+vinacea"
url <- paste0("https://www.xeno-canto.org/api/2/recordings?query=", species)

# Make the GET request
response <- GET(url)

# Parse the response as JSON
data <- content(response, as = "text", encoding = "UTF-8")
parsed_data <- fromJSON(data)
print(parsed_data)

# Extract the relevant geolocation data (latitude, longitude)
xc_data <- parsed_data$recordings %>%
  dplyr::select(id, lat, lng, rec, gen, sp)

xc_data$latitude <- as.numeric(xc_data$lat)
xc_data$longitude <- as.numeric(xc_data$lng)

xc_data$species <- paste(xc_data$gen, xc_data$sp, sep = " ")

# seleciona apenas lon e lat
xc_data <- xc_data %>%
  dplyr::select(lng, lat, species)

xc_data <- xc_data %>%
  rename(lon = lng)

# remove ocorrências duplicadas e NA
xc_data <- xc_data %>%
  distinct() %>%
  drop_na()

xc_data <- xc_data[, c("species", "lon", "lat")]

xc_data$database <- "Xeno-Canto"

# Print the geolocation data
print(xc_data)

write.csv(xc_data, "variaveis/ocorrencias/xeno-canto_filtrado.csv", row.names = FALSE)
