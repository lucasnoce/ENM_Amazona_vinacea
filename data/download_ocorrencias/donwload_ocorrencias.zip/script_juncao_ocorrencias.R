library(dplyr)
library(tidyr)

xc <- read.csv("variaveis/ocorrencias/xeno-canto_filtrado.csv", header = TRUE)
inat <- read.csv("variaveis/ocorrencias/inaturalist_filtrado.csv", header = TRUE)
gbif <- read.csv("variaveis/ocorrencias/gbif_filtrado.csv", header = TRUE)

combined_df <- bind_rows(xc, inat, gbif)

# Write the combined data to a new CSV file
write.csv(combined_df, "variaveis/ocorrencias/ocorrencias_combinado.csv", row.names = FALSE)

combined_df <- combined_df %>%
  filter(!is.na(lon) & !is.na(lat))

# Optionally, remove rows with missing species names if needed
combined_df <- combined_df %>%
  filter(!is.na(species))

# remove ocorrências duplicadas e NA
combined_df <- combined_df %>%
  distinct()


combined_df_flag <- CoordinateCleaner::clean_coordinates(
  x = combined_df,
  species = "species",
  lon = "lon",
  lat = "lat",
  seas_scale = 10,
  tests = c("capitals",       # radius around capitals
            "centroids",      # radius around country and province centroids
            "duplicates",     # records from one species with identical coordinates
            "equal",          # equal coordinates
            "gbif",           # radius around GBIF headquarters
            "institutions",   # radius around biodiversity institutions
            "outliers",       # records far away from all other records of this species
            "seas",           # in the sea
            "urban",          # within urban area
            "validity",       # outside reference coordinate system
            "zeros" ),        # plain zeros and lat = lon
  capitals_rad=100,
  centroids_rad=100
)

combined_df_flag_rem <- combined_df %>%
  dplyr::filter(combined_df_flag$.summary == TRUE)
combined_df_flag
